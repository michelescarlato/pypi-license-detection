"""
Oddly I can't find a test for this function.
"""