Documentation
=============

This is the documentation for {{ cookiecutter.package_name }}.

.. toctree::
  :maxdepth: 2

  {{ cookiecutter.module_name }}/index.rst

.. note:: The layout of this directory is simply a suggestion.  To follow
          traditional practice, do *not* edit this page, but instead place
          all documentation for the package inside ``{{ cookiecutter.module_name }}/``.
          You can follow this practice or choose your own layout.
