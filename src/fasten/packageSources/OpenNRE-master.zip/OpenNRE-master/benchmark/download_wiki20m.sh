mkdir wiki20m
wget -P wiki20m https://thunlp.oss-cn-qingdao.aliyuncs.com/opennre/benchmark/wiki20m/wiki20m_rel2id.json
wget -P wiki20m https://thunlp.oss-cn-qingdao.aliyuncs.com/opennre/benchmark/wiki20m/wiki20m_train.txt
wget -P wiki20m https://thunlp.oss-cn-qingdao.aliyuncs.com/opennre/benchmark/wiki20m/wiki20m_val.txt
wget -P wiki20m https://thunlp.oss-cn-qingdao.aliyuncs.com/opennre/benchmark/wiki20m/wiki20m_test.txt
